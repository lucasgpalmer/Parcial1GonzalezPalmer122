package primerparcialaventurestos;

import java.util.Objects;

public abstract class Aventurero {

    private final String codigo;
    private final String nombre;
    private final Rango rango;

    public Aventurero(String codigo, String nombre, Rango rango) {
        validarString(codigo);
        validarString(nombre);
        Objects.requireNonNull(rango);
        this.codigo = codigo;
        this.nombre = nombre;
        this.rango = rango;
    }

    private static void validarString(String string) {
        if (string == null || string.isBlank() || string.isEmpty()) {
            throw new IllegalArgumentException("Paramentro invalido");
        }
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Rango getRango() {
        return rango;
    }      

    public abstract void atacar();
    
    public abstract int poderCombate();

    @Override
    public int hashCode() {
        return Objects.hash(codigo, nombre);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof Aventurero a && codigo.equals(a.codigo) && nombre.equals(a.nombre)){
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + " codigo=" + codigo + ", nombre=" + nombre + ", rango=" + rango + ", ";
    }
    
    
    
    
    
    
}
