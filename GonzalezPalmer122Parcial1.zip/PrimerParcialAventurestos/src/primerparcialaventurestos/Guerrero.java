package primerparcialaventurestos;

public class Guerrero extends Aventurero implements Entrenable {

    private final int fuerza;
    private static final int CALCULO_FUERZA = 2;

    public Guerrero(String codigo, String nombre, Rango rango, int fuerza) {
        super(codigo, nombre, rango);
        validarFuerza(fuerza);
        this.fuerza = fuerza;
    }

    private static void validarFuerza(int fuerza) {
        if (fuerza < 0) {
            throw new IllegalArgumentException("Fuerza invalida");
        }
    }

    @Override
    public void atacar() {
        System.out.println("Guerrero " + getNombre() + " atacando con su espada");
    }

    /**
     * se hace el calculo del poder de un guerrero
     * @return la fuerza multiplicado por CALCULO_FUERZA = 2
     */
    @Override
    public int poderCombate() {
        return fuerza * CALCULO_FUERZA;
    }

    @Override
    public void entrenar() {
        System.out.println("Guerrero " + getNombre() + " entrenando con armas...");
    }

    @Override
    public String toString() {
        return super.toString() + "fuerza=" + fuerza + '.';
    }

}
