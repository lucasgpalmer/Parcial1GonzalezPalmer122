package primerparcialaventurestos;

public interface Entrenable {
    
    void entrenar();
    
}
