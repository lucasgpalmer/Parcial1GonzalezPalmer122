package primerparcialaventurestos;

public class AventureroYaExistenteException extends RuntimeException {

    public AventureroYaExistenteException() {
    }

    public AventureroYaExistenteException(String msg) {
        super(msg);
    }
}
