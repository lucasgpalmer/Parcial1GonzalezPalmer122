package primerparcialaventurestos;

public enum Rango {
    BRONCE,
    PLATA,
    ORO
}
