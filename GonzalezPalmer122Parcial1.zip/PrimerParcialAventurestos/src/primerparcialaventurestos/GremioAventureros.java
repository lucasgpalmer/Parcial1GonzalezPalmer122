package primerparcialaventurestos;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class GremioAventureros {

    private final String nombre;
    private final List<Aventurero> aventureros;
    
    /**
     * constructor de la clase GremioAventureros, en donde se inicializa vacia la lista aventureros 
     * @param nombre nombre del Gremio
     */
    public GremioAventureros(String nombre) {
        validarNombre(nombre);
        this.nombre = nombre;
        aventureros = new ArrayList<>();
    }

    private static void validarNombre(String nombre) {
        if (nombre == null || nombre.isBlank() || nombre.isEmpty()) {
            throw new IllegalArgumentException("Nombre invalido");
        }
    }

    /**
     * agrega un aventurero a la lista de aventureros
     * @param aventurero aventurero a agregar
     * @exception AventureroYaExistenteException si el aventurero ya esta incluido en la lista
     */
    public void agregarAventurero(Aventurero aventurero) {
        Objects.requireNonNull(aventurero);
        if (aventureros.contains(aventurero)) {
            throw new AventureroYaExistenteException("El aventurero ya esta incluido en la lista");
        }
        aventureros.add(aventurero);
    }

    /**
     * instancia una lista copia de aventureros
     * @return copia de la lista aventureros
     */
    public List<Aventurero> obtenerAventureros() {
        return new ArrayList<Aventurero>(aventureros);
    }

    /**
     * filtra la lista aventureros por tipo de rango
     * @param rango valor del enum para filtrar la lista
     * @return una nueva lista con los aventureros del rango selecionado
     */
    public List<Aventurero> filtrarPorRango(Rango rango) {
        ArrayList<Aventurero> lista = new ArrayList<>();
        for (Aventurero a : aventureros) {
            if (a.getRango() == rango) {
                lista.add(a);
            }
        }
        return lista;
    }

    /**
     * filtra la lista aventureros dejando los que tengan mas poder de combate que el valor seleccionado
     * @param valor valor para filtrar la lista
     * @return una nueva lista con los aventureros de mayor o igual poder de combate que del valor seleccionado
     */
    public List<Aventurero> obtenerAventurerosPoderosos(int valor) {
        ArrayList<Aventurero> lista = new ArrayList<>();
        for (Aventurero a : aventureros) {
            if (a.poderCombate() >= valor) {
                lista.add(a);
            }
        }
        return lista;
    }

}
