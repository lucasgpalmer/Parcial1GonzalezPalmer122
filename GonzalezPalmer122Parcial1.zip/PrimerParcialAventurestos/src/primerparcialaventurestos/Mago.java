package primerparcialaventurestos;

public class Mago extends Aventurero {

    private final int mana;
    private static final int CALCULO_MANA = 10;

    public Mago(String codigo, String nombre, Rango rango, int mana) {
        super(codigo, nombre, rango);
        validarMana(mana);
        this.mana = mana;
    }

    private static void validarMana(int mana) {
        if (mana < 0) {
            throw new IllegalArgumentException("Mana invalido");
        }
    }

    @Override
    public void atacar() {
        System.out.println("Mago " + getNombre() + " disparando bolas de fuego");
    }

    /**
     * se hace el calculo del poder de un mago
     * @return la fuerza sumado por CALCULO_MANA = 10
     */
    @Override
    public int poderCombate() {
        return mana + CALCULO_MANA;
    }

    @Override
    public String toString() {
        return super.toString() + "mana=" + mana + '.';
    }
}
