package primerparcialaventurestos;

public class Arquero extends Aventurero implements Entrenable {

    private final int precision;
    private static final int CALCULO_PRECISION = 3;

    public Arquero(String codigo, String nombre, Rango rango, int precision) {
        super(codigo, nombre, rango);
        validarPrecision(precision);
        this.precision = precision;
    }

    private static void validarPrecision(int precision) {
        if (precision < 0) {
            throw new IllegalArgumentException("Precision invalida");
        }
    }

    @Override
    public void atacar() {
        System.out.println("Arquero " + getNombre() + " disparando flechas");
    }

    /**
     * se hace el calculo del poder de un arquero
     * @return la fuerza multiplicado por CALCULO_PRECISION = 3
     */
    @Override
    public int poderCombate() {
        return precision * CALCULO_PRECISION;
    }

    @Override
    public void entrenar() {
        System.out.println("Arquero " + getNombre() + " disparando a muniecos de practica...");
    }

    @Override
    public String toString() {
        return super.toString() + "precision=" + precision + '.';
    }

}
